
import java.io.IOException;
import java.lang.IllegalArgumentException;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

// importing beans package
import beans.*;

@WebServlet(urlPatterns = {"/gameRoundServlet"})
public class gameRoundServlet extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        boolean lose = false;
        //Ensure right beans are being worked with incase of multiple tabs.
        String username = request.getParameter("username");      
        Cookie userCookie = new Cookie("userID", username);
        response.addCookie(userCookie);
        UserBean userBeanObject;
        GameBean usersGame;
        userBeanObject = (UserBean)session.getAttribute(username);
        usersGame = (GameBean)session.getAttribute(username+"game");
        request.setAttribute("user",userBeanObject);
        request.setAttribute("game",usersGame);
        //Make guesses.
        String[] guesses = request.getParameterValues("Guess[]");
        int[] numbers = new int[guesses.length];
        if(guesses.length != usersGame.getRound())
        {
            throw new IllegalArgumentException("The amount of guesses was incorrect for the corresponding round");
        }
        for(int i = 0; i < guesses.length; i++)
        {
            try{
                numbers[i] = Integer.parseInt(guesses[i]);
            }catch(NullPointerException e)
             {}
             catch(NumberFormatException error)
             {}
            if(usersGame.beenGuessed(numbers[i]) == false)
            {
               throw new IllegalArgumentException("Cannot Guess Previously Guessed Numbers");
            }
        }    
        lose =  usersGame.doGuess(numbers);
        if(lose)
        {
            response.sendRedirect("gameRoundServlet?username="+username+"&lose=true");
        }
        else
        {
          response.sendRedirect("gameRoundServlet?username="+username);
        }
        
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        request.setAttribute("username",(String)request.getParameter("username"));
        request.setAttribute("lose",(String)request.getParameter("lose"));
        RequestDispatcher dispatch = getServletContext().getRequestDispatcher("/WEB-INF/Offer.jsp");
        dispatch.forward(request,response);
    }
    
}


