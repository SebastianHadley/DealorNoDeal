
import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

// importing beans package
import beans.*;

@WebServlet(urlPatterns = {"/continueServlet"})
public class continueServlet extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        HttpSession session = request.getSession();
        String username = request.getParameter("username");      
        String option = request.getParameter("option");
        ServletContext app = getServletContext();
        UserBean userBeanObject;
        GameBean usersGame;
        String continueCheck = request.getParameter("saveCheck");
        if(continueCheck != null)
        {
           
        }
        else if(app.getAttribute(username) == null || option.equals("new"))
        {
            userBeanObject = new UserBean(username);
            usersGame = new GameBean(username);
            //Stores each user and their game for the session.
            session.setAttribute(username, userBeanObject);
            session.setAttribute(username+"game", usersGame);
        }
        else
        {
           userBeanObject = (UserBean)app.getAttribute(username);
           usersGame = (GameBean)app.getAttribute(username+"game");
           app.setAttribute(username,null);
           app.setAttribute(username+"game",null);
        }
        response.sendRedirect("continueServlet?username="+username);
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        request.setAttribute("username",(String)request.getParameter("username"));
        RequestDispatcher dispatch = getServletContext().getRequestDispatcher("/WEB-INF/game.jsp");
        dispatch.forward(request,response);
    }
}
