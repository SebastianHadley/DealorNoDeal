//Package for Beans
package beans;

import java.io.Serializable;

public class UserBean implements Serializable {
    
    private static final long serialVersionUID = 1L;
    private String username;
    //General Constructor 
    public UserBean(){}
    
    //Specific Constructor
    public UserBean(final String user)
    { 
        this.setUsername(user);
        // GameBean game = new GameBean(user);
    }   
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    // public GameBean getGame()
    // {
    //     return game;
    // }
}
