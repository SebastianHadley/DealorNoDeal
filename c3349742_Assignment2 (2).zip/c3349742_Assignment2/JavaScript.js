
function checkGuesses()
{
    var round = document.getElementById('round').value;
    var checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');
    if(checkboxes.length != round)
    {
        alert("Please Guess"+round+" numbers");
        return false;
    }
    return true;
}


function preventSubmit()
{
    var offerForm = document.getElementsByClassName("offer");
    offerForm.addEventListener('submit',check);
}

function check(off)
{
    off.preventDefault();
}


window.addEventListener("popstate",pushHistory(Event));
function pushHistory()
{
    var back = Event.persisted || (typeof window.performance != "undefined" && window.performance.navigation.type == 2);
    if(back)
    {
        let params = (new URL(document.location)).searchParams;
        let name = params.get("username");
        window.location.href = 'Index.jsp?username='+name;
    }
    false;
} 
