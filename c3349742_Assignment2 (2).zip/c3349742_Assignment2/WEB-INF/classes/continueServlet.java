
import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

// importing beans package
import beans.*;

@WebServlet(urlPatterns = {"/continueServlet"})
public class continueServlet extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        HttpSession session = request.getSession();
        String username = request.getParameter("username");      
        String option = request.getParameter("option");
        String backCheck = request.getParameter("backCheck");
        ServletContext app = getServletContext();
        if(backCheck != null)
        {
            app.setAttribute(backCheck+"using",null);
        }
        String using = (String)app.getAttribute(username+"using");
        UserBean userBeanObject;
        GameBean usersGame;
        String continueCheck = request.getParameter("saveCheck");
    
        if(continueCheck != null)
        {
           
        }
        else if(using != null)
        {
            response.sendRedirect("Index.jsp?using=true");
            return;
        }
        else if(app.getAttribute(username) == null || option.equals("new"))
        {
            app.setAttribute(username+"using","true");
            userBeanObject = new UserBean(username);
            usersGame = new GameBean(username);
            //Stores each user and their game for the session.
            session.setAttribute(username, userBeanObject);
            session.setAttribute(username+"game", usersGame);
        }
        else
        {
           app.setAttribute(username+"using","true");
           userBeanObject = (UserBean)app.getAttribute(username);
           usersGame = (GameBean)app.getAttribute(username+"game");
           session.setAttribute(username,userBeanObject);
           session.setAttribute(username+"game",usersGame);
           app.setAttribute(username,null);
           app.setAttribute(username+"game",null);
        }
        response.sendRedirect("continueServlet?username="+username);
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        String check = (String)request.getParameter("username");
        request.setAttribute("username",check);
        RequestDispatcher dispatch = getServletContext().getRequestDispatcher("/WEB-INF/game.jsp");
        dispatch.forward(request,response);
    }
}
