
import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

// importing beans package
import beans.*;

@WebServlet(urlPatterns = {"/saveServlet"})
public class saveServlet extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        HttpSession session = request.getSession();
        String save = request.getParameter("saveCheck");
        String username = request.getParameter("username");      
        String doSave = request.getParameter("saveNow");
        UserBean userBeanObject;
        GameBean usersGame;
        userBeanObject = (UserBean)session.getAttribute(username);
        usersGame = (GameBean)session.getAttribute(username+"game");
        ServletContext app = getServletContext();

        if(doSave != null)
        {      
            app.setAttribute(username+"using",null);
            app.setAttribute(username,userBeanObject);
            app.setAttribute(username+"game",usersGame);
            session.setAttribute(username,null);
            session.setAttribute(username+"game",null);
            response.sendRedirect("Index.jsp");
        }
       else{
        response.sendRedirect("saveServlet?username="+username+"&checkSave="+save);
       }
       
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        request.setAttribute("username",(String)request.getParameter("username"));
        String check =request.getParameter("checkSave");
        request.setAttribute("checkSave",check);
        RequestDispatcher dispatch; 
        dispatch = getServletContext().getRequestDispatcher("/WEB-INF/Offer.jsp");
        dispatch.forward(request,response);
    }
}
