
function checkGuesses()
{
    var round = document.getElementById('round').value;
    var checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');
    if(checkboxes.length != round)
    {
        alert("Please Guess"+round+" numbers");
        return false;
    }
    return true;
}

window.addEventListener("pageshow",forceRefresh(Event));
function forceRefresh(Event)
{
    var back = Event.persisted || (typeof window.performance != "undefined" && window.performance.navigation.type == 2);
    if(back)
    {
        window.location.reload();
    }
    false;
}

function preventSubmit()
{
    var offerForm = document.getElementsByClassName("offer");
    offerForm.addEventListener('submit',check);
}

function check(off)
{
    off.preventDefault();
}


window.addEventListener("popstate",pushHistory(Event));
function pushHistory()
{
    var back = Event.persisted || (typeof window.performance != "undefined" && window.performance.navigation.type == 2);
    if(back)
    {
        window.location.href = 'Index.jsp';
    }
    false;
} 


   var blurred = false;
   window.onblur=function(){blurred = true;};
   window.onfocus = function(){blurred &&(location.reload());}
