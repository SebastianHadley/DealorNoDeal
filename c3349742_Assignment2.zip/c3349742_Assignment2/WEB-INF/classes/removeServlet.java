
import java.io.IOException;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;


@WebServlet(urlPatterns = {"/removeServlet"})
public class removeServlet extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String username = request.getParameter("username");      
        RequestDispatcher dispatch;
        session.setAttribute(username,null);
        session.setAttribute(username+"game",null);
        dispatch = getServletContext().getRequestDispatcher("/Index.jsp");     
        dispatch.forward(request,response);
    }
}


