README.txt
1.The application consists of two beans one for a user and one for a game.
The user object just stores usersname to be retrieved within jsp files.Whereas the game bean is instatiated for each game played and stores the information about that game.
2.Session tracking was implemented through url query parameters that sent the username of a particular user when accessing a game.
3. The game saving was implemented through storing the game and user objects within a ServletContext object that is deleted upon loading.

To start application 
http://localhostxxxxorwhateveryoulike/c3349742_assignment2/
