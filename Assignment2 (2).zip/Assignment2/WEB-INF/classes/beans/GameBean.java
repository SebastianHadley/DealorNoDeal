package beans;
import java.util.concurrent.*;
import java.io.*;
import java.util.Random;
import javax.naming.*;
public class GameBean implements Serializable{ 
    
    private static final long serialVersionUID = 1L;
    private String username;
    private int winNumber;
    private boolean[] guesses;
    private int round;
    private int winPay;
    private boolean inUse;
    //General Constructor
    public GameBean()
    {}
    //Specific Constructor
    public GameBean(String user)
    {
        this.round = 1;
        this.username = user;
        guesses = new boolean[11];
        winNumber = getNumber();
        winPay = winNumber*100;
        inUse = true;
    }

    public void resetGame()
    {
        this.round = 1;
        this.username = null;
        guesses = new boolean[11];
        winNumber = getNumber();
    }
    public void Continue(String user) throws NamingException,IOException
    {
        
        if(user != this.getUsername()){
            throw new NamingException("Username Wrong");
        }
        else
        return;
    }

    public int getNumber()
    {
        Random rand = new Random();
        int temp = rand.nextInt(11);
        return temp+1;
    }
    
    public boolean doGuess(int[] numbers)
    {
        round++;
        boolean lose = false;
        for(int i = numbers.length-1; i >= 0; i--)
        {
            int guess = numbers[i]; 
            guesses[guess-1] = true;
            if(guess == winNumber)
            {
                lose = true;
            }
        }
        return lose;
    }


    public int makeOffer()
    {
      
        for(int i = 0; i < 11; i++)
        {
            if(guesses[i] == false)
            {
                
                return (i+1)*100;
            }
        }
        return 0;
    }
    public void nextRound()
    {


    }
    
    public boolean beenGuessed(int index)
    {
        if(guesses[index-1] == true)
        {
            return false;
        }
        else 
        return true;
    }
    //Getters and Setters
    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    public int getWinNumber() {
        return winNumber;
    }
    public void setWinNumber(int winNumber) {
        this.winNumber = winNumber;
    }
    public boolean[] getGuesses() {
        return guesses;
    }
    public void setGuesses(boolean[] guesses) {
        this.guesses = guesses;
    }
    public int getRound() {
        return round;
    }
    public void setRound(int round) {
        this.round = round;
    }
    public int getWinPay()
    {
        return winPay;
    }
}